package com.greenleaf;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GreenleafVegApplication {

    public static void main(String[] args) {
        SpringApplication.run(GreenleafVegApplication.class, args);
    }
}
